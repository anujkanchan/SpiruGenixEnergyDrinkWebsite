const http = require('http');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');

// MySQL Setup
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Hitansh2005@',  // Add your MySQL password if set
  database: 'emaildb'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL connected');
});

const server = http.createServer((req, res) => {

  // Serving Static Files
  let filePath = './public' + (req.url === '/' ? '/index.html' : req.url);
  const extname = String(path.extname(filePath)).toLowerCase();

  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
  };

  const contentType = mimeTypes[extname] || 'application/octet-stream';

  if (req.method === 'GET' && extname) {
    fs.readFile(filePath, (error, content) => {
      if (error) {
        res.writeHead(404);
        res.end('File Not Found');
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content, 'utf-8');
      }
    });
  }

  // API to Handle Email Submission
  else if (req.method === 'POST' && req.url === '/submit') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { email } = JSON.parse(body);
        if (!email) throw new Error('Invalid Email');

        db.query('INSERT INTO subscribers (email) VALUES (?)', [email], (err) => {
          if (err) {
            res.writeHead(500);
            return res.end('Database Error');
          }
          res.writeHead(200);
          res.end('Email Saved Successfully');
          console.log('New Subscriber:', email);
        });
      } catch {
        res.writeHead(400);
        res.end('Invalid Request');
      }
    });
  }

  else {
    res.writeHead(404);
    res.end('Not Found');
  }

});

server.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
